// import db = require("..")

// const clinicServiceAssociation = ()=>{
//     db.
// }
